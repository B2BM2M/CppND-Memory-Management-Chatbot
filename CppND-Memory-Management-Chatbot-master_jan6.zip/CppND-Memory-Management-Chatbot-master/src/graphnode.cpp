#include "graphedge.h"
#include "graphnode.h"

#include<memory>
GraphNode::GraphNode(int id)
{
    _id = id;
}

GraphNode::~GraphNode()
{
    //// STUDENT CODE
    ////
    /* Jan4
    delete _chatBot; 
    */
    ////
    //// EOF STUDENT CODE
}

void GraphNode::AddToken(std::string token)
{
    _answers.push_back(token);
}
//Jan4 void GraphNode::AddEdgeToParentNode(GraphEdge *edge)
void GraphNode::AddEdgeToParentNode(std::unique_ptr<GraphEdge> &edge)
{
    auto ParentID = edge->GetID();
    //_parentEdges.push_back(edge);
    _parentEdges.push_back(std::make_unique<GraphEdge> (ParentID));
}
//Jan4 void GraphNode::AddEdgeToChildNode(GraphEdge *edge)
void GraphNode::AddEdgeToChildNode(std::unique_ptr<GraphEdge> edge)
{
    //  _childEdges.push_back(edge);
    _childEdges.push_back(std::move(edge));
}

//// STUDENT CODE
////
/// Jan4 void GraphNode::MoveChatbotHere(ChatBot *chatbot)
void GraphNode::MoveChatbotHere(ChatBot chatbot)
{
    /// Jan4 _chatBot = chatbot;
    _chatBot = std::move(chatbot);
    _chatBot.SetCurrentNode(this);
}

void GraphNode::MoveChatbotToNewNode(GraphNode *newNode)
{
    ///Jan4 newNode->MoveChatbotHere(_chatBot);
    newNode->MoveChatbotHere(std::move(_chatBot));
    // Jan4 _chatBot = nullptr; // invalidate pointer at source
}
////
//// EOF STUDENT CODE

GraphEdge *GraphNode::GetChildEdgeAtIndex(int index)
{
    //// STUDENT CODE
    ////

    ///Jan4 return _childEdges[index];
    return _childEdges[index].get();

    ////
    //// EOF STUDENT CODE
}